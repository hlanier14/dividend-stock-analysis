# Copyright (c) 2010-2023 openpyxl

from .rule import Rule
